<?php
symlink('/home/rektechb/report/storage/app/public/', '/home/rektechb/public_html/report/storage');